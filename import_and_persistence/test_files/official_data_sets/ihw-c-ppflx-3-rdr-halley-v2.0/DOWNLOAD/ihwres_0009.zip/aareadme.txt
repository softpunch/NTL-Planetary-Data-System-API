PDS_VERSION_ID = PDS3                                                         
                                                                              
RECORD_TYPE    = "STREAM"                                                     
                                                                              
OBJECT     = TEXT                                                             
  PUBLICATION_DATE = 2006-06-21                                               
  NOTE             = "AAREADME.TXT File"                                      
END_OBJECT = TEXT                                                             
END                                                                           
                                                                              
This volume contains Version 2 of the International Halley Watch (IHW)        
Photometry and Polarimetry Network (PPN) photometric flux data.  These        
data were largely reprocessed by personnel of the PDS Small Bodies            
Node after original submission and archiving.  The reprocessing applied       
uniform reduction techniques and standards to the submitted data, to          
yield a more consistent set of results.                                       
                                                                              
========================                                                      
                                                                              
20 October 2006, A.C.Raugh                                                    
