unsigned Bit( int x )
{
	return( 1 << x );
}
