#include <string.h>

void StrLeft( char *dest, char *src, int num )
{
	strncpy( dest, src, num );
}
