#include <conio.h>

void Beep()
{
	putch( 7 );
}
