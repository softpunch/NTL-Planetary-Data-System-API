unsigned char attrib	  = 7;
unsigned char A_REVERSE   = 0x70;
unsigned char A_NORMAL	  = 0x07;
unsigned char A_BOLD	  = 0x0f;
unsigned char A_UNDERLINE = 0x01;

char *CCMONTHS[12] = { "JAN", "FEB", "MAR", "APR", "MAY", "JUN",
					   "JUL", "AUG", "SEP", "OCT", "NOV", "DEC" };

int CCMonthDays[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

void TcclibInitialize()
{
}
