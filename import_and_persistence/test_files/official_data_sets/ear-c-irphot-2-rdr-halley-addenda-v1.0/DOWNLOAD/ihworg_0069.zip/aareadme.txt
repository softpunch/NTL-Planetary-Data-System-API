PDS_VERSION_ID = PDS3                                                         
                                                                              
RECORD_TYPE    = "STREAM"                                                     
                                                                              
OBJECT     = TEXT                                                             
  PUBLICATION_DATE = 2011-06-13                                               
  NOTE             = "AAREADME File for re-organized IHW data set"            
END_OBJECT = TEXT                                                             
                                                                              
END                                                                           
                                                                              
Re-organized International Halley Watch (IHW) Data Sets                       
=======================================================                       
The original IHW volume HAL_1001 contained three data sets (in addition       
to others) that were considered addenda to data sets in the original          
HAL_0001-HAL_0026 volume set, but were assigned new DATA_SET_IDs for          
one reason or another.  As part of an effort to reorganize physical           
volume-based into the contemporary, single-data-set-per-volume format,        
these data sets have reorganized into the present format. Supporting          
documents from HAL_1001 that were relevant to these data have been            
included in each data set.                                                    
                                                                              
- A.C.Raugh, 2011-06-13                                                       
