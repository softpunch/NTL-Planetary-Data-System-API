package gov.nasa.pds.soap.entities;


public class DataHandler {
    private byte[] content;
    
    public DataHandler() {
    }
    
    public byte[] getContent() {
        return content;
    }
    
    public void setContent(byte[] content) {
        this.content = content;
    }

}
