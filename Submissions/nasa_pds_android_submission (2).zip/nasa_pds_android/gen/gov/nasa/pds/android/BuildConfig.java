/** Automatically generated file. DO NOT MODIFY */
package gov.nasa.pds.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}